package ch12.sec03.exam01;

public class EqualsExample {
}
